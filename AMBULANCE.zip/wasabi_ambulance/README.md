# Wasabi’s ESX Ambulance

## Documentation
[Gitbook - wasabi_ambulance](https://wasabirobby.gitbook.io/wasabi-scripts/scripts/wasabi_ambulance)
