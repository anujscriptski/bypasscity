INSERT INTO `items` (`name`, `label`, `weight`) VALUES
	('pickaxe', 'Pickaxe', 1),
	('emerald', 'Emerald', 20),
	('diamond', 'Diamond', 20),
	('copper', 'Copper', 10),
	('iron', 'Iron', 10),
	('steel', 'Steel', 10)
;